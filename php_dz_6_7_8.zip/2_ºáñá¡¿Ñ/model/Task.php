<?php

class Task
{
    private string $description;
    private bool $isDone;

    public function __construct(string $description, bool $isDone = false)
    {
        $this->description = $description;
        $this->isDone = $isDone;
    }

    public function getDescription(): string
    {
        return $this->description;
    }

    public function setDescription(string $description): self
    {
        $this->description = $description;

        return $this;
    }

    public function isIsDone(): bool
    {
        return $this->isDone;
    }

    public function setIsDone(bool $isDone): self
    {
        $this->isDone = $isDone;

        return $this;
    }
}
