<?php

require_once 'model/User.php';
require_once 'model/Task.php';
require_once 'model/TaskProvider.php';
$pdo = require 'db.php';

session_start();

$username = null;
if (isset($_SESSION['username'])) {
    $username = $_SESSION['username'];
} else {
    header("Location: /");
    die();
}

$pageHeader = 'Задачи';

$user = new TaskProvider($pdo);

if (isset($_GET['action']) && $_GET['action'] === 'add') {

    if (empty($_POST['task'])) {
        throw new Exception('Задача пустая');
    }

    $user->addTask($_POST['task']);
}

if (isset($_GET['done'])) {
    $user->isIsDone($_GET['done']);
}

$user_task = $user->getUndoneList();

require_once 'view/task.php';
