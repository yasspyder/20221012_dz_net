<?php
require_once "model/User.php";
require_once 'model/UserProvider.php';
$pdo = require 'db.php'; // Подключим PDO

session_start();

if (isset($_GET['action']) && $_GET['action'] === 'logout') {
    session_destroy();
    header('Location: /');
    die();
}

$error = null;
if (isset($_POST['username'], $_POST['password'])) {
    ['username' => $username, 'password' => $password] = $_POST;

    $userProvider = new UserProvider($pdo); // Передаем аргумент
    $user = $userProvider->getByUsernameAndPassword($username, $password);

    if ($user === null) {
        $error = 'Пользователь с указанными учетными данными не найден';
    } else {

        $_SESSION['username'] = $user->getUsername();
        $_SESSION['user_id'] = $user->getId();
        header('Location: /');
        die();
    }
}

require_once 'view/signin.php';
