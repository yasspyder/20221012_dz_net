<head>
    <meta charset="UTF-8">
    <title>Главная</title>
</head>

<body>
    <h1><?= $pageHeader ?></h1>
    <?php if ($username !== null) : ?>
        <a href="?controller=task">[Ваши задачи]</a>
        <a href="?controller=security&action=logout">[Выйти]</a>
        <p>Рады вас приветствовать, <?= $_SESSION['username'] ?>!</p>
    <?php else : ?>
        <a href="?controller=security">[Войти]</a>
        <a href="?controller=registration">[Зарегистрироваться]</a>
    <?php endif ?>
</body>