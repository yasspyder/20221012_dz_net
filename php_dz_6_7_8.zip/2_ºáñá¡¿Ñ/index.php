<?php

require_once 'errorHandler.php';
require_once 'model/Logger.php';

$controller = $_GET['controller'] ?? 'home';
$routes = require 'routes.php';

try {
    require_once $routes[$controller];
} catch (PDOException $exception) {
    echo "Сервис временно не доступен. <a href='?controller=home'>На главную страницу</a>";
} catch (Exception $exception) {
    echo $exception->getMessage() . " <a href='?controller=home'>На главную страницу</a>";
    die();
}
