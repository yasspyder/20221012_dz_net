<?php

require_once 'model/User.php';
require_once 'model/Task.php';
require_once 'model/TaskProvider.php';

session_start();

$username = null;
if (isset($_SESSION['username'])) {
    $username = $_SESSION['username'];
} else {
    header("Location: /");
    die();
}

$pageHeader = 'Задачи';

if (isset($_GET['done'])) {
    foreach ($_SESSION['task'] as $key) {
        if ($key->getDescription() == $_GET['done']) {
            $key->setIsDone(true);
        }
    }
}

$user = new TaskProvider();

if (isset($_GET['action']) && $_GET['action'] === 'add') {
    $user->addTask($_POST['task']);
    header("Location: /?controller=task");
    die();
}

$user_task = $user->getUndoneList();

require_once 'view/task.php';
