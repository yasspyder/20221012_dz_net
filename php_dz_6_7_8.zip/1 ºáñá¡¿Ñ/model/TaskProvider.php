<?php

class TaskProvider
{
    private array $task;

    public function __construct()
    {
        $this->task = $_SESSION['task'] ?? [];
    }

    public function getUndoneList(): array
    {
        $arr = [];
        foreach ($this->task as $key) {
            if (!($key->isIsDone())) {
                $arr[] = $key;
            }
        }
        return $arr;
    }

    public function addTask(string $task_text): void
    {
        $new_task = new Task($task_text);
        $_SESSION['task'][] = $new_task;
        $this->task[] = $new_task;
    }

    public function getTask(): array
    {
        return $this->task;
    }


    public function setTask(array $task): self
    {
        $this->task = $task;

        return $this;
    }
}
