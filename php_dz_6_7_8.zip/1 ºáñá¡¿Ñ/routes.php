<?php

return [
    'home' => 'controller/HomeController.php',
    'security' => 'controller/SecurityController.php',
    'task' => 'controller/TaskController.php'
];
