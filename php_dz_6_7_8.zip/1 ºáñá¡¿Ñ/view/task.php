<head>
    <meta charset="UTF-8">
    <title>Задачи</title>
</head>

<body>
    <h1><?= $pageHeader ?></h1>
    <a href="?controller=home">[Главная страница]</a>
    <a href="?controller=security&action=logout">[Выйти]</a>
    <form action="/?controller=task&action=add" method="post">
        <input type="text" name="task" size="20" placeholder="описание задачи">
        <input type="submit" value="Добавить">
    </form>
    <?php if (isset($user_task) && count($user_task) > 0) : ?>
        <ol>
            <?php foreach ($user_task as $task) : ?>
                <li>
                    <?= $task->getDescription() ?> <a href="?controller=task&done=<?= $task->getDescription() ?>">[Done]</a>;
                </li>
            <?php endforeach; ?>
        </ol>
    <?php else : ?>
        <h3>У вас нет не выполненных задач.</h3>
    <?php endif; ?>
</body>