<?php
require_once 'model/Task.php';

class TaskProvider
{
    private array $task = [];

    public function getUndoneList(): void
    {
        $arr = [];
        foreach ($this->task as $key) {
            if ($key->isIsDone() == false) {
                $arr[] = $key->getDescription();
            }
        }
        // не производительно наверное каждый раз перезаписывать, но я пока других способов не знаю
        $_SESSION['tasks'] = $arr;
    }

    public function addTask(string $task_text): void
    {
        $new_task = new Task($task_text);
        self::setTask($new_task);
        self::getUndoneList();
    }
    public function setTask(Task $task): self
    {
        $this->task[] = $task;

        return $this;
    }

    public function getTask()
    {
        return $this->task;
    }
}
