<?php

require_once 'model/TaskProvider.php';

//session_start();

$pageHeader = 'Задачи';

// создание обьекта TaskProvider и добавление задач
$user = new TaskProvider();

$user->addTask('погулять с котом');
$user->addTask('сходить в магазин');
$user->addTask('поехать на дачу');
$user->addTask('сотворить чушь');
$user->addTask('сотворить доброе дело');
$user->addTask('сотворить плохое дело');
$user->addTask('исправить всё, что натворил');

// вывод из текущей сесии списка задач
$task_list = function () {
    if (isset($_SESSION['tasks'])) {
        echo '<ol>';
        foreach ($_SESSION['tasks'] as $task) {
            echo '<li>';
            echo $task . " <a href=''>[Done]</a>";
            echo '</li>';
        }
        echo '</ol>';
    } else {
        echo "<h3>Активных задач нет</h3>";
    }
};

include 'view/task.php';
