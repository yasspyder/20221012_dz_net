<head>
    <meta charset="UTF-8">
    <title>Задачи</title>
</head>

<body>
    <h1><?= $pageHeader ?></h1>
    <a href="?controller=home">[Главная страница]</a>
    <a href="?controller=security&action=logout">[Выйти]</a>    
    <?= $task_list(); ?>
    <form>
        <input type="text" size="20" placeholder="описание задачи">
        <button type="submit">Добавить</button>
    </form>
</body>